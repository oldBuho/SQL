This is the solution for the hardest SQL challenge on HackerRank ::  <br>  https://www.hackerrank.com/challenges/15-days-of-learning-sql/problem

I´m leaving here two functional queries:
<br>
  A) formattedQuery_and_comments :: this is the "readable" one...
<br>
  B) unformatted_code_for_hackerRank :: this is unformatted, the plataform supported only this type of code/query. Also, this is meant to be used only in the Oracle enviroment. 

<br>
<br>
https://www.linkedin.com/posts/federicojuiz_sql-data-programming-activity-6908139534857715712-7Eov
